<?php

namespace App\Http\Controllers;

use App\Models\Account;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;

class AccountController extends Controller
{
    public function index(){
    	$accounts = Account::all();

    	return view('account.index')
    		->with('accounts', $accounts);
    }

    public function data(){
    	$accounts = Account::all();

    	return json_encode([
    			'response'	=> 'success',
    			'data'		=> $accounts,
    		]);
    }

    public function create(){
    	return view('account.create');
    }

    public function save(Request $req){
    	$feedback = [
            'status'    => 'success',
        ];

    	$account = new account();
        $account->username 			= $req->username;
        $account->password 			= bcrypt($req->password);
        $account->name 				= $req->name;
        $account->role 				= $req->role;

        $account->save();

        $feedback['accountid'] = $account->username;

        Session::flash('feedback', $feedback);
            
        return redirect()
        	->route('account.index');
    }

    public function change(Request $req){
    	$account = account::find($req->username);

    	return view('account.update')
    		->with('account', $account);
    }

    public function update(Request $req){
    	$feedback = [
            'status'    => 'success',
        ];

    	$account = account::find($req->idaccount);
        $account->username 			= $req->username;
        $account->password 			= bcrypt($req->password);
        $account->name 				= $req->name;
        $account->role 				= $req->role;

        $account->save();

        $feedback['accountid'] = $account->idaccount;

        Session::flash('feedback', $feedback);
            
        return redirect()
        	->route('account.index');
    }

    public function delete(Request $req){
    	$feedback = [
            'status'    => 'success',
        ];

    	$account = account::find($req->idaccount);
        $account->delete();

        Session::flash('feedback', $feedback);
            
        return redirect()
        	->route('account.index');
    }
}
