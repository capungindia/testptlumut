<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Posts</div>

                <div class="card-body">

                    <div class="btn btn-group">
                        <a class="btn btn-sm btn-success" href="<?php echo e(route('account.create')); ?>">
                            New Account
                        </a>
                    </div>
                    
                    <table class="table table-striped table-hover" id="post-table" width="100%">
                        <thead>
                            <tr>
                                <th>Manage</th>
                                <th>Username</th>
                                <th>Name</th>
                                <th>Role</th>
                            </tr>
                        </thead>

                        <tbody>
                            <?php $__currentLoopData = $accounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $account): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>
                                        <div class="btn btn-group">
                                            <a class="btn btn-sm btn-warning" href="<?php echo e(route('account.change')); ?>?username=<?php echo e($account->username); ?>">
                                                Edit
                                            </a>
                                            <a class="btn btn-sm btn-danger" href="<?php echo e(route('account.delete')); ?>?username=<?php echo e($account->username); ?>">
                                                Delete
                                            </a>
                                        </div>
                                    </td>
                                    <td><?php echo e($account->username); ?></td>
                                    <td><?php echo e($account->name); ?></td>
                                    <td><?php echo e($account->role); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\testlumut\resources\views/account/index.blade.php ENDPATH**/ ?>