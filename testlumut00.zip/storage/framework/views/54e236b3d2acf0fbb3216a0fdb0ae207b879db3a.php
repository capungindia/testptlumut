<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Posts</div>

                <div class="card-body">

                    <div class="btn btn-group">
                        <a class="btn btn-sm btn-success" href="<?php echo e(route('post.create')); ?>">
                            New
                        </a>
                    </div>
                    
                    <table class="table table-striped table-hover" id="post-table" width="100%">
                        <thead>
                            <tr>
                                <th>Manage</th>
                                <th>Title</th>
                                <th>Content</th>
                                <th>Date</th>
                                <th>Author</th>
                            </tr>
                        </thead>

                        <tbody>
                            <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>
                                        <div class="btn btn-group">
                                            <a class="btn btn-sm btn-warning" href="<?php echo e(route('post.change')); ?>?idpost=<?php echo e($post->idpost); ?>">
                                                Edit
                                            </a>
                                            <a class="btn btn-sm btn-danger" href="<?php echo e(route('post.delete')); ?>?idpost=<?php echo e($post->idpost); ?>">
                                                Delete
                                            </a>
                                        </div>
                                    </td>
                                    <td><?php echo e($post->title); ?></td>
                                    <td><?php echo e($post->content); ?></td>
                                    <td><?php echo e($post->date); ?></td>
                                    <td><?php echo e($post->username); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\testlumut\resources\views/post/index.blade.php ENDPATH**/ ?>